"""Global game settings."""

WIDTH = 1100
HEIGHT = 700
FPS = 60

GROUND_Y = 610

TITLE = "Stickman Fighter"

# Colors
SKY_TOP = (110, 185, 235)
SKY_BOTTOM = (220, 240, 250)
GROUND = (62, 120, 70)
GROUND_DARK = (38, 78, 45)
BLACK = (25, 28, 32)
WHITE = (245, 247, 250)
RED = (215, 55, 60)
GREEN = (70, 190, 95)
BLUE = (55, 115, 225)
YELLOW = (250, 205, 70)
PANEL = (22, 28, 38)

