import random

import pygame

from enemy import Enemy
from player import Player
from settings import (
    BLACK,
    FPS,
    GROUND,
    GROUND_DARK,
    GROUND_Y,
    HEIGHT,
    PANEL,
    SKY_BOTTOM,
    SKY_TOP,
    WHITE,
    WIDTH,
    YELLOW,
)
from ui import draw_hud, draw_text, make_font


class Game:
    """Owns the main loop and switches between menu, play and game-over states."""

    MENU = "menu"
    PLAYING = "playing"
    GAME_OVER = "game_over"

    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.title_font = make_font(58, True)
        self.medium_font = make_font(30, True)
        self.small_font = make_font(22)
        self.state = self.MENU
        self.running = True
        self.debug_hitbox = False
        self.reset()

    def reset(self):
        self.player = Player()
        self.enemies = []
        self.score = 0
        self.level = 1
        self.kills = 0
        self.next_spawn = pygame.time.get_ticks() + 800

    def start(self):
        self.reset()
        self.state = self.PLAYING

    def handle_event(self, event):
        if event.type == pygame.QUIT:
            self.running = False
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if self.state == self.PLAYING:
                    self.state = self.MENU
                else:
                    self.running = False
                return

            if event.key == pygame.K_F1:
                self.debug_hitbox = not self.debug_hitbox

            if self.state == self.MENU and event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.start()
                return

            if self.state == self.GAME_OVER and event.key == pygame.K_r:
                self.start()
                return

        if self.state == self.PLAYING:
            self.player.handle_event(event)

    def spawn_enemy(self):
        alive_count = sum(not enemy.dead for enemy in self.enemies)
        maximum = min(2 + self.level // 2, 6)
        if alive_count < maximum:
            self.enemies.append(Enemy(self.level))

    def update(self, dt):
        if self.state != self.PLAYING:
            return

        self.player.update(dt)
        now = pygame.time.get_ticks()

        if now >= self.next_spawn:
            self.spawn_enemy()
            delay = max(1500 - self.level * 60, 700)
            self.next_spawn = now + delay

        attack_rect = self.player.attack_rect()

        for enemy in self.enemies:
            enemy.update(dt, self.player)

            if attack_rect and attack_rect.colliderect(enemy.rect):
                was_alive = not enemy.dead
                if enemy.take_hit(20, self.player.attack_id, self.player.facing) and was_alive and enemy.dead:
                    self.kills += 1
                    self.score += 100
                    self.level = 1 + self.kills // 5

        self.enemies = [enemy for enemy in self.enemies if not enemy.dead]

        if self.player.health <= 0:
            self.state = self.GAME_OVER

    def draw_background(self):
        # Lightweight vertical sky gradient.
        for y in range(0, GROUND_Y, 8):
            t = y / GROUND_Y
            color = tuple(int(SKY_TOP[i] * (1 - t) + SKY_BOTTOM[i] * t) for i in range(3))
            pygame.draw.rect(self.screen, color, (0, y, WIDTH, 8))

        pygame.draw.circle(self.screen, YELLOW, (910, 105), 48)
        pygame.draw.rect(self.screen, GROUND, (0, GROUND_Y, WIDTH, HEIGHT - GROUND_Y))
        pygame.draw.line(self.screen, GROUND_DARK, (0, GROUND_Y), (WIDTH, GROUND_Y), 5)

        # Distant scenery
        pygame.draw.polygon(self.screen, (125, 165, 145), [(0, GROUND_Y), (190, 330), (390, GROUND_Y)])
        pygame.draw.polygon(self.screen, (105, 150, 135), [(230, GROUND_Y), (480, 370), (730, GROUND_Y)])

    def draw(self):
        self.draw_background()

        if self.state == self.MENU:
            self.draw_menu()
        elif self.state == self.PLAYING:
            for enemy in self.enemies:
                enemy.draw(self.screen)
            self.player.draw(self.screen, self.debug_hitbox)
            draw_hud(self.screen, self.player, self.score, self.level, self.small_font)
            controls = self.small_font.render("A/D Move   W/Space Jump   J Attack   F1 Hitbox   Esc Menu", True, BLACK)
            self.screen.blit(controls, (24, HEIGHT - 38))
        else:
            self.player.draw(self.screen)
            self.draw_game_over()

        pygame.display.flip()

    def draw_panel(self, width, height):
        panel = pygame.Surface((width, height), pygame.SRCALPHA)
        panel.fill((*PANEL, 225))
        rect = panel.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        self.screen.blit(panel, rect)
        pygame.draw.rect(self.screen, WHITE, rect, 2, border_radius=12)
        return rect

    def draw_menu(self):
        rect = self.draw_panel(660, 330)
        draw_text(self.screen, "STICKMAN FIGHTER", self.title_font, WHITE, (WIDTH // 2, rect.top + 78))
        draw_text(self.screen, "A / D  Move     W / Space  Jump     J  Attack", self.small_font, WHITE, (WIDTH // 2, rect.top + 160))
        draw_text(self.screen, "Press ENTER to start", self.medium_font, YELLOW, (WIDTH // 2, rect.top + 240))

    def draw_game_over(self):
        rect = self.draw_panel(540, 290)
        draw_text(self.screen, "GAME OVER", self.title_font, WHITE, (WIDTH // 2, rect.top + 70))
        draw_text(self.screen, f"Score: {self.score}    Defeated: {self.kills}", self.medium_font, YELLOW, (WIDTH // 2, rect.top + 145))
        draw_text(self.screen, "Press R to restart", self.medium_font, WHITE, (WIDTH // 2, rect.top + 220))

    def run(self):
        while self.running:
            dt = min(self.clock.tick(FPS) / 1000.0, 0.05)

            for event in pygame.event.get():
                self.handle_event(event)

            self.update(dt)
            self.draw()

