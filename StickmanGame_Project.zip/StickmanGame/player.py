import math

import pygame

from settings import BLACK, BLUE, GROUND_Y, RED, WIDTH


class Player:
    """The player character: movement, jumping, attacking and health."""

    def __init__(self):
        self.width = 44
        self.height = 88
        self.x = 130.0
        self.y = float(GROUND_Y - self.height)
        self.vy = 0.0

        self.speed = 330.0
        self.jump_speed = -650.0
        self.gravity = 1800.0
        self.on_ground = True
        self.facing = 1
        self.walk_time = 0.0

        self.max_health = 100
        self.health = self.max_health

        self.attacking = False
        self.attack_started = 0
        self.attack_duration = 180
        self.attack_cooldown = 340
        self.last_attack = -self.attack_cooldown
        self.attack_id = 0

        self.invincible_until = 0
        self.hurt_flash_until = 0

    @property
    def rect(self):
        return pygame.Rect(round(self.x), round(self.y), self.width, self.height)

    @property
    def center_x(self):
        return int(self.x + self.width / 2)

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return

        if event.key in (pygame.K_w, pygame.K_UP, pygame.K_SPACE):
            self.jump()
        elif event.key == pygame.K_j:
            self.attack()

    def jump(self):
        if self.on_ground:
            self.vy = self.jump_speed
            self.on_ground = False

    def attack(self):
        now = pygame.time.get_ticks()
        if now - self.last_attack >= self.attack_cooldown:
            self.attacking = True
            self.attack_started = now
            self.last_attack = now
            self.attack_id += 1

    def update(self, dt):
        keys = pygame.key.get_pressed()
        direction = 0

        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            direction -= 1
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            direction += 1

        if direction:
            self.facing = direction
            self.x += direction * self.speed * dt
            self.walk_time += dt * 12

        self.x = max(0, min(WIDTH - self.width, self.x))

        self.vy += self.gravity * dt
        self.y += self.vy * dt

        floor_y = GROUND_Y - self.height
        if self.y >= floor_y:
            self.y = float(floor_y)
            self.vy = 0
            self.on_ground = True

        now = pygame.time.get_ticks()
        if self.attacking and now - self.attack_started >= self.attack_duration:
            self.attacking = False

    def attack_rect(self):
        if not self.attacking:
            return None

        y = int(self.y + 25)
        if self.facing == 1:
            return pygame.Rect(int(self.x + self.width - 2), y, 72, 42)
        return pygame.Rect(int(self.x - 70), y, 72, 42)

    def take_damage(self, amount, source_x):
        now = pygame.time.get_ticks()
        if now < self.invincible_until or self.health <= 0:
            return False

        self.health = max(0, self.health - amount)
        self.invincible_until = now + 650
        self.hurt_flash_until = now + 140
        self.x += 24 if self.center_x > source_x else -24
        return True

    def draw(self, surface, show_hitbox=False):
        now = pygame.time.get_ticks()
        color = RED if now < self.hurt_flash_until else BLACK

        cx = self.center_x
        top = int(self.y)
        head = (cx, top + 14)
        neck = (cx, top + 28)
        shoulder = (cx, top + 38)
        hip = (cx, top + 58)

        walking = pygame.key.get_pressed()[pygame.K_a] or pygame.key.get_pressed()[pygame.K_d]
        stride = int(math.sin(self.walk_time) * 13) if walking and self.on_ground else 0

        if self.on_ground:
            left_foot = (cx - 14 + stride, top + 87)
            right_foot = (cx + 14 - stride, top + 87)
        else:
            left_foot = (cx - 18, top + 75)
            right_foot = (cx + 18, top + 75)

        if self.attacking:
            punch_hand = (cx + self.facing * 67, top + 39)
            back_hand = (cx - self.facing * 16, top + 47)
            if self.facing == 1:
                left_hand, right_hand = back_hand, punch_hand
            else:
                left_hand, right_hand = punch_hand, back_hand
        else:
            left_hand = (cx - 20, top + 49 - stride // 2)
            right_hand = (cx + 20, top + 49 + stride // 2)

        pygame.draw.circle(surface, color, head, 13, 4)
        pygame.draw.circle(surface, color, (cx + self.facing * 5, top + 12), 2)
        pygame.draw.line(surface, color, neck, hip, 5)
        pygame.draw.line(surface, color, shoulder, left_hand, 5)
        pygame.draw.line(surface, color, shoulder, right_hand, 5)
        pygame.draw.line(surface, color, hip, left_foot, 5)
        pygame.draw.line(surface, color, hip, right_foot, 5)

        # Blue belt makes the player easy to distinguish from enemies.
        pygame.draw.line(surface, BLUE, (cx - 7, top + 58), (cx + 7, top + 58), 5)

        if show_hitbox and self.attacking:
            pygame.draw.rect(surface, RED, self.attack_rect(), 2)

