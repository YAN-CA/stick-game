import pygame

from settings import BLACK, GREEN, PANEL, RED, WHITE


def make_font(size, bold=False):
    return pygame.font.SysFont("arial", size, bold=bold)


def draw_text(surface, text, font, color, center):
    image = font.render(text, True, color)
    rect = image.get_rect(center=center)
    surface.blit(image, rect)


def draw_bar(surface, x, y, width, height, value, maximum, color):
    pygame.draw.rect(surface, PANEL, (x, y, width, height), border_radius=6)
    ratio = max(0, min(1, value / maximum))
    pygame.draw.rect(surface, color, (x, y, int(width * ratio), height), border_radius=6)
    pygame.draw.rect(surface, WHITE, (x, y, width, height), 2, border_radius=6)


def draw_hud(surface, player, score, level, small_font):
    draw_bar(surface, 24, 22, 260, 24, player.health, player.max_health, GREEN if player.health > 30 else RED)
    hp = small_font.render(f"HP {player.health}/{player.max_health}", True, WHITE)
    surface.blit(hp, (34, 24))

    score_image = small_font.render(f"Score: {score}    Level: {level}", True, BLACK)
    surface.blit(score_image, (24, 58))

