import pygame

from game import Game
from settings import HEIGHT, TITLE, WIDTH


def main():
    pygame.init()
    pygame.display.set_caption(TITLE)
    screen = pygame.display.set_mode((WIDTH, HEIGHT))

    game = Game(screen)
    game.run()

    pygame.quit()


if __name__ == "__main__":
    main()

