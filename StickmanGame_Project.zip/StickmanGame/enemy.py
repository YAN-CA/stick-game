import math
import random

import pygame

from settings import BLACK, GROUND_Y, RED, WIDTH


class Enemy:
    """A simple melee enemy that follows and attacks the player."""

    def __init__(self, level=1):
        self.width = 42
        self.height = 84
        self.x = float(WIDTH + random.randint(20, 180))
        self.y = float(GROUND_Y - self.height)
        self.speed = min(105 + level * 7, 190)
        self.max_health = 40 + level * 4
        self.health = self.max_health
        self.damage = min(8 + level, 18)

        self.attacking = False
        self.attack_until = 0
        self.last_attack = -1000
        self.attack_cooldown = max(1050 - level * 20, 650)
        self.last_hit_by = -1
        self.hurt_until = 0
        self.dead = False
        self.walk_time = random.random() * 5

    @property
    def rect(self):
        return pygame.Rect(round(self.x), round(self.y), self.width, self.height)

    @property
    def center_x(self):
        return int(self.x + self.width / 2)

    def update(self, dt, player):
        if self.dead:
            return

        distance = player.center_x - self.center_x
        now = pygame.time.get_ticks()

        if abs(distance) > 58:
            direction = 1 if distance > 0 else -1
            self.x += direction * self.speed * dt
            self.walk_time += dt * 10
        elif now - self.last_attack >= self.attack_cooldown:
            self.attacking = True
            self.attack_until = now + 220
            self.last_attack = now
            player.take_damage(self.damage, self.center_x)

        if now >= self.attack_until:
            self.attacking = False

        self.x = max(-20, min(WIDTH + 20, self.x))

    def take_hit(self, damage, attack_id, direction):
        if self.dead or self.last_hit_by == attack_id:
            return False

        self.last_hit_by = attack_id
        self.health = max(0, self.health - damage)
        self.hurt_until = pygame.time.get_ticks() + 130
        self.x += direction * 32

        if self.health == 0:
            self.dead = True
        return True

    def draw(self, surface):
        if self.dead:
            return

        color = RED if pygame.time.get_ticks() < self.hurt_until else BLACK
        cx = self.center_x
        top = int(self.y)
        direction = -1
        stride = int(math.sin(self.walk_time) * 10)

        pygame.draw.circle(surface, color, (cx, top + 13), 12, 4)
        pygame.draw.circle(surface, color, (cx + direction * 5, top + 11), 2)
        pygame.draw.line(surface, color, (cx, top + 26), (cx, top + 56), 5)

        if self.attacking:
            front_hand = (cx + direction * 54, top + 38)
        else:
            front_hand = (cx + direction * 20, top + 47)

        pygame.draw.line(surface, color, (cx, top + 36), front_hand, 5)
        pygame.draw.line(surface, color, (cx, top + 36), (cx - direction * 18, top + 48), 5)
        pygame.draw.line(surface, color, (cx, top + 56), (cx - 13 + stride, top + 83), 5)
        pygame.draw.line(surface, color, (cx, top + 56), (cx + 13 - stride, top + 83), 5)

        # Enemy health bar
        bar = pygame.Rect(int(self.x - 2), top - 13, self.width + 4, 6)
        pygame.draw.rect(surface, (55, 58, 64), bar, border_radius=3)
        fill = bar.copy()
        fill.width = int(bar.width * self.health / self.max_health)
        pygame.draw.rect(surface, RED, fill, border_radius=3)

