# 火柴人格斗游戏

这是一个使用 Python 和 Pygame 制作的可扩展电脑端火柴人动作游戏项目。

## 当前功能

- 开始菜单、游戏界面和失败界面
- 火柴人左右移动、跳跃和出拳攻击
- 敌人自动追踪并近身攻击
- 玩家与敌人的生命值
- 受伤闪烁、击退、攻击冷却和短暂无敌
- 得分、击败数量和动态难度
- 按 F1 显示或隐藏玩家攻击判定框
- 游戏失败后按 R 重新开始

## 在 PyCharm 中打开

1. 解压下载的 `StickmanGame.zip`。
2. 打开 PyCharm，选择“打开”。
3. 选择解压后的 `StickmanGame` 文件夹。
4. 确认项目使用你的 Python/Conda 虚拟环境。
5. 在 PyCharm 终端执行：

```bash
pip install -r requirements.txt
```

6. 打开 `main.py`，点击右上角绿色运行按钮。

## 操作

| 按键 | 功能 |
| --- | --- |
| Enter | 开始游戏 |
| A / D 或左右方向键 | 左右移动 |
| W / 空格 / 上方向键 | 跳跃 |
| J | 攻击 |
| F1 | 显示攻击判定框 |
| Esc | 返回菜单或退出 |
| R | 游戏失败后重新开始 |

## 文件结构

```text
StickmanGame/
├─ main.py          游戏入口
├─ game.py          游戏主循环、状态与流程
├─ player.py        玩家移动、跳跃、攻击与绘制
├─ enemy.py         敌人AI、受伤与绘制
├─ ui.py            血条、字体和界面组件
├─ settings.py      窗口、帧率和颜色等配置
├─ requirements.txt 依赖列表
└─ README.md        使用说明
```

游戏暂时不依赖图片和音频素材，所有图形均由 Pygame 实时绘制，方便继续学习和修改。

